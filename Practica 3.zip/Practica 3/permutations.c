/**
 *
 * Descripcion: Implementation of function that generate permutations
 *
 * File: permutations.c
 * Autor: Carlos Aguirre
 * Version: 1.1
 * Fecha: 21-09-2019
 *
 */

#include <assert.h>
#include "permutations.h"

/***************************************************/
/* Function: random_num Date: 6-10-2020            */
/* Authors: Sergio Larriba Moreno                  */
/*                                                 */
/* Rutine that generates a random number           */
/* between two given numbers                       */
/*                                                 */
/* Input:                                          */
/* int inf: lower limit                            */
/* int sup: upper limit                            */
/* Output:                                         */
/* int: random number                              */
/***************************************************/
int random_num(int inf, int sup)
{
  assert(sup>=inf); 
  return inf + (int) (((sup-inf+1.0)*rand()) / (RAND_MAX+1.0)); 
}

/***************************************************/
/* Function: generate_perm Date: 6-10-2020         */
/* Authors: Sergio Larriba Moreno                  */
/*                                                 */
/* Rutine that generates a random permutation      */
/*                                                 */
/* Input:                                          */
/* int n: number of elements in the permutation    */
/* Output:                                         */
/* int *: pointer to integer array                 */
/* that contains the permitation                   */
/* or NULL in case of error                        */
/***************************************************/
int* generate_perm(int N)
{
  int i, *perm, randnum, aux; 

  if (N<=-1) return NULL; 

  perm = (int*) malloc (N * sizeof (perm[0])); 
  if (perm == NULL) return NULL; 

  for (i=0; i<N; i++) {
    perm[i] = i+1; 
  }

  /* poner en la memoria que el algoritmo de permutaciones se llama algoritmo de Fisher-Yates */
  for (i=0; i<N; i++)
  {
    randnum = random_num(i, N-1);
    aux = perm[i]; 
    perm[i] = perm[randnum];
    perm[randnum] = aux;  
  }

  return perm; 
}

/***************************************************/
/* Function: generate_permutations Date: 6-10-2020 */
/* Authors: Sergio Larriba Moreno                  */
/*                                                 */
/* Function that generates n_perms random          */
/* permutations with N elements                    */
/*                                                 */
/* Input:                                          */
/* int n_perms: Number of permutations             */
/* int N: Number of elements in each permutation   */
/* Output:                                         */
/* int**: Array of pointers to integer that point  */
/* to each of the permutations                     */
/* NULL en case of error                           */
/***************************************************/
int** generate_permutations(int n_perms, int N)
{
  int i, **perms; 

  if (n_perms <= 0 || N < 0) return NULL; 

  perms = (int**) malloc (n_perms * sizeof (perms[0])); 
  if (perms == NULL) return NULL; 

  for (i=0; i<n_perms; i++)
  {
    /* Genero una permutacion */
    perms[i] = generate_perm (N); 
    if (perms[i] == NULL) 
    {
      for (--i; i>=0; i--)
      {
        free (perms[i]); 
      }
      free (perms); 
      return NULL; 
    }
  }

  return perms; 
}

