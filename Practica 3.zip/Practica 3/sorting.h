/**
 *
 * Descripcion: Header file for sorting functions 
 *
 * Fichero: sorting.h
 * Autor: Carlos Aguirre
 * Version: 1.0
 * Fecha: 16-09-2019
 *
 */

#ifndef SORTING_H
#define SORTING_H

/* constants */

#ifndef ERR
  #define ERR -1
  #define OK (!(ERR))
#endif

#include <stdio.h>
#include <stdlib.h>
#include <stddef.h>

/* type definitions, devuelve un entero y recibe un puntero y 2 enteros */
typedef int (* pfunc_sort)(int*, int, int);

/* Functions */

int SelectSort(int* array, int ip, int iu);
int SelectSortInv(int* array, int ip, int iu);
int min(int* array, int ip, int iu, int *ob);
int merge(int* tabla, int ip, int iu, int imedio); 
int mergesort(int* tabla, int ip, int iu); 
int quicksort(int* tabla, int ip, int iu); 
int median(int *tabla, int ip, int iu, int *pos); 
int partition(int* tabla, int ip, int iu,int *pos); 
void swap (int *x, int *y); 
int median_avg(int *tabla, int ip, int iu, int *pos); 
int median_stat(int*tabla, int ip, int iu, int *pos); 

#endif
