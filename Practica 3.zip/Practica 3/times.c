/**
 *
 * Descripcion: Implementation of time measurement functions
 *
 * Fichero: times.c
 * Autor: Carlos Aguirre Maeso
 * Version: 1.0
 * Fecha: 16-09-2019
 *
 */
#include <time.h>
#include <assert.h>
#include <stdlib.h>
#include <stdio.h>
#include "times.h"
#include "sorting.h"
#include "permutations.h"
#include "search.h"

/* 
1 condicion por assert, assert para el control de errores, incluir la libreira <assert.h>
calculo el punto medio de la tabla, divido en dos mitades, y sigo asi recursivamente , primero laparte izquierda, hasta que solo me quede 1 elemento
mirar en la pagina hacker earth, es muy util
pseudocodigo mergesort: 
  1. assert de los parametros
  2. caso base -> solo hay un elemento en la tabla (no podemos dividir mas) (ip == iu)
  3. calcula el punto medio middle = (ip + iu) / 2
  4. dividir, llamo a merge sort de la tabla izqda 
      mergesort(tabla, ip, middle), parte izqda
      mergesort(tabla, middle+1, iu), parte dcha
  5. merge (tabla, ip, iu, middle)

  complejidad NlogN, ya que es algoritmo divide y venceras entonces hay un log por ahi por medio y como minimo divido la tabla N veces
*/

/********************************************************/
/* Function: average_sorting_time Date: 14-10-2022      */
/* Authors: Sergio Larriba Moreno                       */
/*                                                      */
/* Function that measures times                         */
/*                                                      */
/* Input:                                               */
/* pfunc_sort: pointer to an extern function            */
/* int n_nperms: number of permutations                 */
/* int N: size of permutations                          */
/* PTIMEAA_AA: pointer to the struct of time            */
/* Output:                                              */
/* OK if everything goes well                           */
/* ERR en case of error                                 */
/********************************************************/
short average_sorting_time(pfunc_sort metodo, int n_perms, int N, PTIME_AA ptime)
{
  int **matriz=NULL, i, ob, min, max; 
  clock_t t_start=0, t_end=0; 
  double time_taken, media, cont=0.0; 

  min = INT_MAX; 
  max = INT_MIN; 

  if (metodo == NULL || ptime == NULL || n_perms<0 || N<0) {
    return ERR; 
  }
  /* Genero la matriz de permutaciones */
  matriz = generate_permutations (n_perms, N); 
  if (matriz == NULL) {
    return ERR; 
  }
  /* Clock antes de ordenar */
  t_start = clock(); 
  if (t_start == (clock_t) -1) 
  {
    for(i = 0; i < n_perms; i++) {
      free(matriz[i]);
    }
    free (matriz); 
    return ERR; 
  }
  
  for (i=ob=0; i<n_perms; i++)
  {
    /* Ordeno con select sort cada permutacion de la matriz */
    ob = metodo (matriz[i], 0, N-1); 
    /* Control de errores */
    if (ob == ERR) 
    {
      for(i = 0; i < n_perms; i++) {
        free(matriz[i]);
      }
      free (matriz); 
      return ERR; 
    }

    /* Busco cuantas veces se ejecuta como maximo y minimo la operacion basica */
    if (max < ob) 
    {
      max = ob; 
    } 
    if (min > ob)
    {
      min = ob; 
    }

    /* Clock despues de ordenar */
    t_end = clock(); 
    /* Control de errores */
    if (t_end == (clock_t) -1) 
    {
      for(i = 0; i < n_perms; i++) {
        free(matriz[i]);
      }
      free (matriz); 
      return ERR; 
    }

    /* Cuento cuantas veces se ejecuta la operacion basica */
    cont += ob; 
  }
  /* Tiempo en milisegundos que tarda en ejecutar todas las permutaciones */
  time_taken = (double) ((t_end-t_start)*1000000)/CLOCKS_PER_SEC;
  /* Hago la media en milisegundos entre todas las permutaciones */ 
  media = (double) time_taken / n_perms; 

  /* Guardo los datos en PTIME */
  ptime->N = N; 
  ptime->n_elems = n_perms; 
  ptime->time = media; 
  ptime->average_ob = (double) (cont / n_perms); 
  ptime->min_ob = min; 
  ptime->max_ob = max; 

  /* Libero memoria */
  for(i = 0; i < n_perms; i++) 
  {
    free(matriz[i]);
  }
  free (matriz); 

  return OK; 
}

/********************************************************/
/* Function: generate_sorting_times Date: 14-10-2022    */
/* Authors: Sergio Larriba Moreno                       */
/*                                                      */
/* Function that generates an array of times            */
/* Writes on a file min_ob, max_ob, time                */
/*                                                      */
/* Input:                                               */
/* pfunc_sort: pointer to an extern function            */
/* int n_nperms: number of permutations                 */
/* char* file: name to the file                         */
/* int num_min: minimum number of elements              */
/*              on the first permutation                */
/* int num_max: maximum number of elements              */
/*              on the last permutation                 */
/* int incr: number that increments the size of         */
/*           the permutations                           */
/*                                                      */
/* Output:                                              */
/* OK if everything goes well                           */
/* ERR en case of error                                 */
/********************************************************/
short generate_sorting_times(pfunc_sort method, char* file, int num_min, int num_max, int incr, int n_perms)
{
  int num_estructuras_tiempo, i, j; 
  PTIME_AA time; 

  if (method == NULL || file == NULL || num_min < 0 || num_max < 0) return ERR; 

  /* Calculo cuantas estructuras de tiempo necesito */
  for (i=num_min, num_estructuras_tiempo=0; i<=num_max; )
  {
    num_estructuras_tiempo++; 
    i = i + incr; 
  }
  
  /* Reservo memoria para el array de tiempo */
  time = (PTIME_AA) malloc (num_estructuras_tiempo * sizeof (time[0])); 
  if (time == NULL) return ERR; 
  
  for (i=num_min, j=0; i<=num_max; i = i + incr)
  {
    if (average_sorting_time (method, n_perms, i, &time[j++]) == ERR)
    {
      free(time); 
      return ERR; 
    }
  }

  /* Imprimo el array de tiempos en un fichero */
  if (save_time_table (file, time, num_estructuras_tiempo) == ERR)
  {
    free (time); 
    return ERR; 
  }

  /* Libero memoria */
  free (time); 

  return OK; 
}

/********************************************************/
/* Function: save_time_table Date: 14-10-2022           */
/* Authors: Sergio Larriba Moreno                       */
/*                                                      */
/* Function that saves the data on a file               */
/*                                                      */
/* Input:                                               */               
/* char* file: name to the file                         */
/* int num_min: minimum number of elements              */
/* PTIME_AA: array of times                             */
/* int n_times: number of elements on the times array   */
/*                                                      */
/* Output:                                              */
/* OK if everything goes well                           */
/* ERR en case of error                                 */
/********************************************************/
short save_time_table(char* file, PTIME_AA ptime, int n_times)
{
  FILE *f; 
  int i, str; 

  if (file == NULL || ptime == NULL ) return ERR; 

  /* Abro el fichero */
  f = fopen (file, "w"); 
  if (f == NULL) return ERR; 

  /* Inserto los datos en el fichero */
  for(i = 0; i < n_times; i++){
    str = fprintf(f, "%d %f %f %d %d\n",ptime[i].N, ptime[i].time, ptime[i].average_ob, ptime[i].max_ob, ptime[i].min_ob);
    if (str<0) 
    {
      fclose (f); 
      return ERR; 
    }
  }

  /* Cierro el fichero */
  fclose (f); 

  return OK; 
}

short average_search_time(pfunc_search metodo, pfunc_key_generator generator, int order,int N, int n_times, PTIME_AA ptime)
{
  PDICT pdict; 
  int *perm=NULL, *keys=NULL, tam, i, ob=0, min, max, pos; 
  clock_t t_start=0, t_end=0; 
  double time_taken, media, cont=0.0; 

  min = INT_MAX; 
  max = INT_MIN; 
  
  assert(metodo!=NULL); 
  assert(generator!=NULL); 
  assert(order>=0); 
  assert(N>=0); 
  assert(n_times>=0); 
  assert(ptime!=NULL); 

  tam = N*n_times; 

  /* Crear un diccionario de tamaño N */
  pdict = init_dictionary(N, order); 
  if (pdict == NULL) 
  {
    return ERR; 
  }

  /* Creo una permutacion de tamaño N */
  perm = generate_perm (N); 
  if (perm == NULL) 
  {
    free_dictionary(pdict); 
    return ERR; 
  }

  /* Inserto todos los elementos de la permutación en el diccionario */
  massive_insertion_dictionary(pdict, perm, N); 

  /* Reservar memoria para el arra que contendrá las claves */
  keys = (int*) malloc (tam * sizeof(keys[0])); 
  if (keys == NULL) 
  {
    free_dictionary(pdict); 
    free(perm); 
    return ERR; 
  }

  /* Relleno el array de claves con las claves */
  generator(keys, tam, N); 

  /* Clock antes de ordenar */
  t_start = clock(); 
  if (t_start == (clock_t)-1) 
  {
    free_dictionary(pdict); 
    free(perm); 
    free(keys); 
    return ERR; 
  }

  /* Busco las claves */
  for (i=0; i<tam; i++) 
  {
    ob = search_dictionary(pdict, keys[i], &pos, metodo); 
    
    /* Busco cuantas veces se ejecuta como maximo y minimo la operacion basica */
    if (max < ob) 
    {
      max = ob; 
    } 
    if (min > ob)
    {
      min = ob; 
    }

    /* Clock despues de ordenar */
    t_end = clock(); 
    if (t_end == (clock_t) -1) 
    {
      free_dictionary(pdict); 
      free(perm); 
      free(keys);  
      return ERR; 
    }

    cont += ob; 
  }
  
  /* Tiempo en microsegundos que tarda en ejecutar todas las permutaciones */
  time_taken = (double) ((t_end-t_start)*1000000)/CLOCKS_PER_SEC;
  /* Hago la media en milisegundos entre todas las permutaciones */ 
  media = (double) time_taken / tam; 

  /* Guardo los datos en PTIME */
  ptime->N = N; 
  ptime->n_elems = tam; 
  ptime->time = media; 
  ptime->average_ob = (double) (cont / tam); 
  ptime->min_ob = min; 
  ptime->max_ob = max; 

  /* Libero memoria */
  free_dictionary(pdict); 
  free(perm); 
  free(keys); 

  return cont; 
}

short generate_search_times(pfunc_search method, pfunc_key_generator generator, int order, char* file, int num_min, int num_max, int incr, int n_times)
{
  int num_estructuras_tiempo, i, j; 
  PTIME_AA time; 

  assert(method!=NULL); 
  assert(generator!=NULL); 
  assert(order>=0); 
  assert(file!=NULL); 
  assert(num_min>=0); 
  assert(num_max>=0); 
  assert(num_min<=num_max); 
  assert(incr>=0); 
  assert(n_times>=0); 

  /* Calculo cuantas estructuras de tiempo necesito */
  for (i=num_min, num_estructuras_tiempo=0; i<=num_max; )
  {
    num_estructuras_tiempo++; 
    i = i + incr; 
  }
  
  /* Reservo memoria para el array de tiempo */
  time = (PTIME_AA) malloc (num_estructuras_tiempo * sizeof (time[0])); 
  if (time == NULL) return ERR; 
  
  for (i=num_min, j=0; i<=num_max; i = i + incr)
  {
    if (average_search_time (method, generator, order, i, n_times, &time[j++]) == ERR)
    {
      free(time); 
      return ERR; 
    }
  }

  /* Imprimo el array de tiempos en un fichero */
  if (save_time_table (file, time, num_estructuras_tiempo) == ERR)
  {
    free (time); 
    return ERR; 
  }

  /* Libero memoria */
  free (time); 

  return OK; 
}

