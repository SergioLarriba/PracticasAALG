/**
 *
 * Descripcion: Headers for time measurement functions 
 *
 * Fichero: times.h
 * Author: Carlos Aguirre / Javier Sanz-Cruzado
 * Version: 1.0
 * Date: 14-11-2019
 *
 */



short generate_search_times(pfunc_search method, pfunc_key_generator generator, 
                                int order, char* file, 
                                int num_min, int num_max, 
                                int incr, int n_times);

/* igual que la que teniamos para sorting, solo cambiamos en esta rutina el tamaño del diccionario

ob+tiempo busqueda lineal, busqueda lineal autoorganizada y la otra busqueda lineal */


short average_search_time(pfunc_search metodo, pfunc_key_generator generator,
                              int order,
                              int N, 
                              int n_times,
                              PTIME_AA ptime);

/* 
init_dictionary(order, N)
perm = generate_perm(N)
massive_insertion(perm)
keys = malloc(N*n_times) (crear una variable N*n_times, ya que lo usamos mucho)
generator(keys, N*n_times, N)
pongo el clok ini
for (i=0; i<=N*n_times; i++) {
    search_dictionary(method)
}
pongo el clock end
rellenar la estructura de tiempos
libero memoria -> diccionario, permutaciones, claves
*/

