/**
 *
 * Descripcion: Implementation of sorting functions
 *
 * Fichero: sorting.c
 * Autor: Carlos Aguirre
 * Version: 1.0
 * Fecha: 16-09-2019
 *
 */


#include <assert.h>
#include "sorting.h"

/********************************************************/
/* Function: SelectSort Date: 7-10-2022                 */
/* Authors: Sergio Larriba Moreno                       */
/*                                                      */
/* Function that orders an array                        */
/*                                                      */
/* Input:                                               */
/* int array: Array to order                            */
/* int ip: position of the first element of the array   */
/* int iu: position of the last element of the array    */
/* Output:                                              */
/* int: the number of times the ob is executed          */
/* ERR en case of error                                 */
/********************************************************/

int SelectSort(int* array, int ip, int iu) 
{
  int i, min_pos=0, ob=0; 

  if (array==NULL) return ERR;

  for (i=ip; i<=iu; i++)
  {
    min_pos = min (array, i, iu, &ob); 
    if (min_pos == ERR) {
      return ERR; 
    }

    swap(&array[i], &array[min_pos]); 
  }
  return ob; 
}

/********************************************************/
/* Function: SelectSortInv Date: 7-10-2022              */
/* Authors: Sergio Larriba Moreno                       */
/*                                                      */
/* Function that orders an array                        */
/*                                                      */
/* Input:                                               */
/* int array: Array to order                            */
/* int ip: position of the first element of the array   */
/* int iu: position of the last element of the array    */
/* Output:                                              */
/* int: the number of times the ob is executed          */
/* ERR en case of error                                 */
/********************************************************/

int SelectSortInv(int* array, int ip, int iu)
{
  int min_pos=0, i, ob=0; 

  if (array == NULL) return ERR; 

  for (i=iu; i>=ip; i--)
  {
    min_pos = min (array, ip, i, &ob); 
    if (min_pos == ERR) {
      return ERR; 
    }
  
    swap(&array[i], &array[min_pos]); 
  }
  return ob; 
}

int min(int* array, int ip, int iu, int *ob)
{
  int min_pos=ip, j; 

  if (array == NULL) return ERR; 
  
  for (j=ip+1; j<=iu; j++)
  {
    if (++(*ob) && (array[j] < array[min_pos])) { 
      min_pos = j;  
    }
  }
  return min_pos; 
}

/* 
1 condicion por assert, assert para el control de errores, incluir la libreira <assert.h>
calculo el punto medio de la tabla, divido en dos mitades, y sigo asi recursivamente , primero laparte izquierda, hasta que solo me quede 1 elemento
mirar en la pagina hacker earth, es muy util
pseudocodigo mergesort: 
  1. assert de los parametros
  2. caso base -> solo hay un elemento en la tabla (no podemos dividir mas) (ip == iu)
  3. calcula el punto medio middle = (ip + iu) / 2
  4. dividir, llamo a merge sort de la tabla izqda 
      mergesort(tabla, ip, middle), parte izqda
      mergesort(tabla, middle+1, iu), parte dcha
  5. merge (tabla, ip, iu, middle)

  complejidad NlogN, ya que es algoritmo divide y venceras entonces hay un log por ahi por medio y como minimo divido la tabla N veces
*/

/**
* Ordena un array. Ordena un array de manera creciente mediante la forma "divide y vencerás"
* @param tabla (int*) puntero a la tabla que queremos ordenar
* @param ip (int) indice del primer elemento de la tabla
* @param iu (int) indice del ultimo elemento de la tabla
* @return El total de operaciones basicas realizadas al ordenar la tabla
*/
int mergesort(int* tabla, int ip, int iu)
{
  int middle=0, ob, i=0, j=0, k=0; 

  assert(tabla!=NULL); 
  assert(ip>=0);
  assert(iu>=0); 
  assert(ip<iu); 

  /* Caso base */
  if (ip == iu)
  {
    return OK; 
  }
  /* Calculo el punto medio */
  middle = (ip+iu)/2; 
  /* Voy dividiendo la tabla en subtablas pequeñas */
  i = mergesort(tabla, ip, middle); /* Separo la parte izqda sucesivamente */
  j = mergesort(tabla, middle+1, iu); /* Separo la parte dcha sucesivamente */
  /* Junto ambas tablas */
  k=merge(tabla, ip, iu, middle); 

  ob = i + j + k; 
  return ob; 
}

/**
* Ordena y combina tablas. Ordena en orden creciente y combina las subtablas/elementos generadas por la rutina mergesort
* @param tabla (int*) puntero a la subtabla 
* @param ip (int) indice del primer elemento de la tabla
* @param iu (int) indice del ultimo elemento de la tabla
* @param imedia (int) indice del elemento que ocupa la mitad de la tabla
* @return El total de operaciones basicas realizadas al ordenar la tabla
*/
int merge(int* tabla, int ip, int iu, int imedio)
{
  int *tabla_aux=NULL, tam_tabla_aux=0, i, j, k, ob=0; 
  
  /* Control de errores */
  assert(tabla!=NULL); 
  assert(ip>=0);
  assert(iu>=0); 
  assert(imedio>=0); 

  /* Veo el tamaño de la tabla auxiliar */
  for (i=ip; i<=iu; i++) {
    tam_tabla_aux++; 
  }
  /* Creo la tabla auxiliar */
  tabla_aux = (int*) malloc (tam_tabla_aux * sizeof (tabla[0])); 
  assert(tabla_aux != NULL); 
  i=ip; 
  j=imedio+1; 
  /* Uno las tablas en la tabla auxiliar en orden creciente */
  for (k=0; i<=imedio && j<=iu; k++)
  {
    if (++ob && tabla[i]<tabla[j]) 
    {
      tabla_aux[k] = tabla[i]; 
      i++; 
      ob++; 
    }
    else 
    {
      tabla_aux[k] = tabla[j]; 
      j++; 
    }
  }
  /* Copio el resto de la tabla derecha */
  if (i>imedio)
  {
    while (j<=iu)
    {
      tabla_aux[k] = tabla[j]; 
      j++; 
      k++; 
    }
  }
  /* Copio el resto de la tabla izquierda */
  else if (j>iu)
  {
    while (i<=imedio)
    {
      tabla_aux[k] = tabla[i]; 
      i++; 
      k++; 
    }
  }
  /* Copio la tabla auxiliar a la tabla input */
  for (i=ip, k=0; i<=iu; i++, k++) 
  {
    tabla[i] = tabla_aux[k]; 
  }
  /* Libero memoria */
  free (tabla_aux); 

  return ob; 
}
/*
f(x)=x*log(x)
plot "merge.log" using 1:3, f(x) -> poner esto en gnuplot para comparar las graficas
g(x)=a*x*log(a*x)+b
ajuste curvas -> fit g(x) "merge.log" using 1:3 via a,b
plot "merge.log" using 1:3, g(x)

mergesort: si solo cuento las comparaciones de clave ob=1/2N y su cuento tmb las de juntar ob=N

quicksort-> complejidad: nlog(n)
1. assert de los paramatros
2. (ip == iu) return
3. pivote llamando a median
4. partition()
5. if (ip < pos-1) {quicksort(tabla, ip, pos-1)}; parte izqda
   if (pos+1 < iu) {quicksort(tabla, pos+1, iu)}; parte dcha
en partir no llamar a median


hacer la grafica del caso peor en quicksort, tenemos que pasarle a quicksort un array ordenado, seria un ajuste de curvas cuadratico
*/


/**
* Ordena un array. Ordena un array de manera creciente mediante la forma "divide y vencerás"
* @param tabla (int*) puntero a la tabla que queremos ordenar
* @param ip (int) indice del primer elemento de la tabla
* @param iu (int) indice del ultimo elemento de la tabla
* @return El total de operaciones basicas realizadas al ordenar la tabla
*/
int quicksort(int* tabla, int ip, int iu){

  int pivote=0, ob=0;

  assert(tabla!=NULL); 
  assert(ip<iu); 
  assert(ip>=0); 
  assert(ip>=0); 

  if(ip==iu) return OK;

  ob += partition(tabla, ip, iu, &pivote);

  if(ip<pivote-1){
    ob += quicksort(tabla, ip, pivote-1);
  }
  if(pivote+1<iu){
    ob += quicksort(tabla, pivote+1, iu);
  }

  return ob;
}

/**
* Ordena un array respecto a un pivote. 
  Ordena un array de manera creciente respecto un pivote de tal manera que los elementos menores que el 
    pivote quedan a su izquierda, y los mayores a su derecha
* @param tabla (int*) puntero a la tabla que queremos ordenar
* @param ip (int) indice del primer elemento de la tabla
* @param iu (int) indice del ultimo elemento de la tabla
* @param pos (int*) puntero al pivote de la tabla 
* @return El total de operaciones basicas realizadas 
*/
int partition(int* tabla, int ip, int iu,int *pos)
{
  int k, i;

  assert(tabla!=NULL); 
  assert(pos!=NULL); 
  assert(ip>=0); 
  assert(ip>=0); 

  median_stat(tabla, ip, iu, pos);                           

  k = tabla[*pos];                                        

  swap(&tabla[ip], &tabla[*pos]);                                  

  *pos = ip;                                              

  for(i=ip; i<=iu; i++){                          
    if(tabla[i]<k){
      (*pos)++; 
      swap(&tabla[i], &tabla[*pos]);
    }
  }
  swap(&tabla[ip], &tabla[*pos]); 
  return i;
} 

/**
* Elige un pivote. Asigna el pivote a la primera posicion de la tabla 
* @param tabla (int*) puntero a la tabla que queremos ordenar
* @param ip (int) indice del primer elemento de la tabla
* @param iu (int) indice del ultimo elemento de la tabla
* @param pos (int*) puntero al pivote de la tabla 
* @return OK 
*/
int median(int *tabla, int ip, int iu, int *pos)
{
  assert(tabla!=NULL); 
  assert(pos!=NULL); 
  assert(ip>=0); 
  assert(ip>=0); 
  assert(ip<iu);

  *pos = ip;
  return OK;
}


/**
* Elige un pivote. Asigna el pivote a la posicion media de la tabla 
* @param tabla (int*) puntero a la tabla que queremos ordenar
* @param ip (int) indice del primer elemento de la tabla
* @param iu (int) indice del ultimo elemento de la tabla
* @param pos (int*) puntero al pivote de la tabla 
* @return La posicion media de la tabla
*/
int median_avg(int *tabla, int ip, int iu, int *pos)
{
  int media; 

  assert(tabla!=NULL); 
  assert(pos!=NULL); 
  assert(ip>=0); 
  assert(ip>=0); 
  assert(ip<iu);

  media = (ip+iu)/2; 

  *pos=media; 

  return media; 
}
/* Poner en la memoria que las comparaciones de clave que realizamos en median_stat no las cuento, porq 
son muy pocas y no afecta al rendimiento global de quicksort 
nlog(n) caso medio
n² caso peor*/

/**
* Elige un pivote. Asigna el pivote a la posicion del elemento de la tabla con el valor intermedio entre los 
  elementos que ocupan las posiciones ip, iu, y la posición media de la tabla. 
* @param tabla (int*) puntero a la tabla que queremos ordenar
* @param ip (int) indice del primer elemento de la tabla
* @param iu (int) indice del ultimo elemento de la tabla
* @param pos (int*) puntero al pivote de la tabla 
* @return OK 
*/
int median_stat(int*tabla, int ip, int iu, int *pos)
{
  int media, array[3][2]; 

  assert(tabla!=NULL); 
  assert(pos!=NULL); 
  assert(ip>=0); 
  assert(ip>=0); 
  assert(ip<iu); 

  media = (ip+iu)/2; 

  /* Inicializo la matriz, guardo el numero y su posicion en la tabla*/
  array[0][0] = tabla[ip]; 
  array[0][1] = ip; 
  array[1][0] = tabla[iu]; 
  array[1][1] = iu; 
  array[2][0] = tabla[media]; 
  array[2][1] = media; 

  /* Ordeno el array */
  if (array[0][0] > array[1][0])
  {
    swap(&array[0][0], &array[1][0]); 
    swap(&array[0][1], &array[1][1]); 
  }

  if (array[1][0] > array[2][0])
  {
    swap(&array[1][0], &array[2][0]); 
    swap(&array[1][1], &array[2][1]); 
    if (array[0][0] > array[1][0])
    {
      swap(&array[0][0], &array[1][0]); 
      swap(&array[0][1], &array[1][1]); 
    }
  }
  *pos = array[1][1]; /* El pivote es el elemento del medio */
  return OK; 
}

/**
* Intercambia dos elementos. Asigna el valor de un elemento al otro, y viceversa
* @param x (int*) puntero al primer elemento
* @param y (int*) puntero al segundo elemento
*/
void swap (int *x, int *y)
{
  int tmp;
  assert(x!=NULL); 
  assert(y!=NULL); 
  tmp = *x;
  *x = *y;
  *y = tmp;
  return; 
}